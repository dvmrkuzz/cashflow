// Trinity Cashflow Modeller — server-side email hand-off
// Receives a base64 PDF from the browser and emails it to the onboarding inbox.
// Credentials come from Netlify environment variables and are never sent to the browser.

const nodemailer = require('nodemailer');

const MAX_PDF_BYTES = 8 * 1024 * 1024; // 8 MB ceiling

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return json(405, { error: 'Method not allowed' });
  }

  // ── Config: accepts existing project variable names ──
  // SMTP_USER / SMTP_PASS are required. Host and port are inferred from the
  // sender's domain if not set. Recipient falls back to ADVISER_EMAIL.
  const SMTP_USER = process.env.SMTP_USER;
  const SMTP_PASS = process.env.SMTP_PASS;
  const MAIL_TO   = process.env.MAIL_TO || process.env.ONBOARDING_EMAIL || process.env.ADVISER_EMAIL;
  const MAIL_FROM = process.env.MAIL_FROM || SMTP_USER;

  if (!SMTP_USER || !SMTP_PASS) {
    console.error('Missing SMTP_USER or SMTP_PASS');
    return json(500, { error: 'Email is not configured on the server.' });
  }
  if (!MAIL_TO) {
    console.error('No recipient: set MAIL_TO (or ADVISER_EMAIL)');
    return json(500, { error: 'No recipient address is configured.' });
  }

  const inferred = inferSmtp(SMTP_USER);
  const SMTP_HOST = process.env.SMTP_HOST || inferred.host;
  const SMTP_PORT = Number(process.env.SMTP_PORT) || inferred.port;

  if (!SMTP_HOST) {
    console.error('Could not infer SMTP host — set SMTP_HOST explicitly');
    return json(500, { error: 'Mail server is not configured.' });
  }

  // ── Parse and validate the payload ──
  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'Malformed request body.' });
  }

  const { filename, pdfBase64, clientName, reportDate, preparedBy } = payload;

  if (!pdfBase64 || typeof pdfBase64 !== 'string') {
    return json(400, { error: 'No PDF supplied.' });
  }

  const pdfBuffer = Buffer.from(pdfBase64, 'base64');
  if (pdfBuffer.length === 0) {
    return json(400, { error: 'PDF was empty.' });
  }
  if (pdfBuffer.length > MAX_PDF_BYTES) {
    return json(413, { error: 'PDF is too large to email (over 8 MB).' });
  }
  // Sanity check: real PDFs start with %PDF
  if (pdfBuffer.slice(0, 4).toString() !== '%PDF') {
    return json(400, { error: 'File does not appear to be a PDF.' });
  }

  // Never trust a client-supplied filename directly
  const safeFilename = String(filename || 'Trinity-Cashflow.pdf')
    .replace(/[^a-z0-9._-]+/gi, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 120) || 'Trinity-Cashflow.pdf';

  const safeClient = String(clientName || 'Unnamed client').slice(0, 120);
  const safeDate = String(reportDate || new Date().toLocaleDateString('en-GB')).slice(0, 40);
  const safePreparer = String(preparedBy || '').slice(0, 120);

  // ── Send ──
  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: SMTP_PORT,
    secure: SMTP_PORT === 465,
    auth: { user: SMTP_USER, pass: SMTP_PASS }
  });

  const subject = `Cashflow projection — ${safeClient} — ${safeDate}`;

  const text =
    `Illustrative cashflow projection attached for ${safeClient}, prepared ${safeDate}.\n` +
    (safePreparer ? `Prepared by: ${safePreparer}\n` : '') +
    `\n` +
    `This projection is illustrative only and does not constitute regulated financial advice. ` +
    `Growth is shown net of the charges stated in the assumptions bar. Tax on withdrawals, ` +
    `sequencing risk and legislative changes are not modelled.\n\n` +
    `Sent automatically by the Trinity Cashflow Modeller.\n`;

  const html =
    `<p>Illustrative cashflow projection attached for <strong>${escapeHtml(safeClient)}</strong>, prepared ${escapeHtml(safeDate)}.</p>` +
    (safePreparer ? `<p>Prepared by: ${escapeHtml(safePreparer)}</p>` : '') +
    `<p style="color:#6b7a8f;font-size:12px;line-height:1.6">This projection is illustrative only and does not constitute regulated financial advice. ` +
    `Growth is shown net of the charges stated in the assumptions bar. Tax on withdrawals, sequencing risk and legislative changes are not modelled.</p>` +
    `<p style="color:#9aa5b1;font-size:11px">Sent automatically by the Trinity Cashflow Modeller.</p>`;

  try {
    await transporter.sendMail({
      from: MAIL_FROM || SMTP_USER,
      to: MAIL_TO,
      subject,
      text,
      html,
      attachments: [{ filename: safeFilename, content: pdfBuffer, contentType: 'application/pdf' }]
    });
  } catch (err) {
    console.error('SMTP send failed:', err.message);
    return json(502, { error: 'The email could not be sent. Please download the PDF and send it manually.' });
  }

  return json(200, { ok: true, to: MAIL_TO, filename: safeFilename });
};

function inferSmtp(address) {
  const domain = String(address).split('@')[1]?.toLowerCase() || '';
  if (/^(gmail\.com|googlemail\.com)$/.test(domain)) return { host: 'smtp.gmail.com', port: 587 };
  if (/^(outlook\.com|hotmail\.com|live\.com|office365\.com)$/.test(domain)) return { host: 'smtp.office365.com', port: 587 };
  return { host: null, port: 587 }; // custom domain — set SMTP_HOST explicitly
}

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  };
}

function escapeHtml(str) {
  return str.replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}
